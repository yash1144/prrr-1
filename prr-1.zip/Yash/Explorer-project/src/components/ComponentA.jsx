function ComponentA() {
    return (
      <>
          <h2>Hello 1</h2> 
      </>
    )
  }
  
  export default ComponentA