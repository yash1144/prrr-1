function ComponentB() {
    return (
      <>
          <h2>Hello 2</h2> 
      </>
    )
  }
  
  export default ComponentB